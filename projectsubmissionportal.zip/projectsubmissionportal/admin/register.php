<?php
include("includes/db.php");

$message = "";

if(isset($_POST['register']))
{
    $name = mysqli_real_escape_string($conn,$_POST['name']);
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $password = password_hash($_POST['password'],PASSWORD_DEFAULT);

    $check = mysqli_query($conn,"SELECT * FROM students WHERE email='$email'");

    if(mysqli_num_rows($check)>0)
    {
        $message = "<div class='alert alert-danger'>Email Already Registered!</div>";
    }
    else
    {
        $sql = "INSERT INTO students(name,email,password)
                VALUES('$name','$email','$password')";

        if(mysqli_query($conn,$sql))
        {
            echo "<script>
            alert('Registration Successful');
            window.location='login.php';
            </script>";
            exit();
        }
        else
        {
            $message = "<div class='alert alert-danger'>Registration Failed!</div>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Student Registration</title>

<link rel="stylesheet" href="css/style.css">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">

</head>

<body>

<nav>

<div class="logo">
Project Portal
</div>

<ul>

<li><a href="index.php">Home</a></li>

<li><a href="login.php">Student Login</a></li>

<li><a href="faculty/login.php">Faculty Login</a></li>

</ul>

</nav>

<div class="container mt-5">

<div class="row justify-content-center">

<div class="col-md-6">

<div class="card shadow-lg border-0 rounded-4">

<div class="card-header bg-success text-white text-center">

<h3>

<i class="fa-solid fa-user-plus"></i>

Student Registration

</h3>

</div>

<div class="card-body p-4">

<?php echo $message; ?>

<form method="POST">

<div class="mb-3">

<label class="form-label">

Full Name

</label>

<input
type="text"
name="name"
class="form-control"
required>

</div>

<div class="mb-3">

<label class="form-label">

Email

</label>

<input
type="email"
name="email"
class="form-control"
required>

</div>

<div class="mb-3">

<label class="form-label">

Password

</label>

<input
type="password"
name="password"
class="form-control"
required>

</div>

<div class="d-grid">

<button
type="submit"
name="register"
class="btn btn-success btn-lg">

<i class="fa-solid fa-user-check"></i>

Register

</button>

</div>

</form>

<hr>

<p class="text-center">

Already have an account?

<a href="login.php">

Login Here

</a>

</p>

</div>

</div>

</div>

</div>

</div>

</body>

</html>