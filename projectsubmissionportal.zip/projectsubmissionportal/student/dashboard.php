<?php
include("../includes/db.php");
session_start();

if(!isset($_SESSION['student_name']))
{
    header("Location: ../login.php");
    exit();
}

$name = $_SESSION['student_name'];

$total = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM projects WHERE student_name='$name'"));

$pending = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM projects WHERE student_name='$name' AND status='Pending'"));

$approved = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM projects WHERE student_name='$name' AND status='Approved'"));

$rejected = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM projects WHERE student_name='$name' AND status='Rejected'"));

$status = "No Project Uploaded";

$sql = "SELECT * FROM projects
        WHERE student_name='$name'
        ORDER BY id DESC LIMIT 1";

$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0)
{
    $row=mysqli_fetch_assoc($result);
    $status=$row['status'];
}
?>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Student Dashboard</title>

<link rel="stylesheet"
href="../css/style.css">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">

<style>

body{
background:#eef3f8;
}

.dashboard-header{

background:linear-gradient(135deg,#2563eb,#0f172a);

padding:40px;

color:white;

border-radius:15px;

margin-top:30px;

}

.stat-card{

background:white;

border-radius:15px;

padding:25px;

box-shadow:0 5px 15px rgba(0,0,0,.15);

text-align:center;

transition:.3s;

}

.stat-card:hover{

transform:translateY(-8px);

}

.stat-card i{

font-size:40px;

color:#2563eb;

margin-bottom:15px;

}

.status-box{

background:white;

padding:25px;

margin-top:30px;

border-radius:15px;

box-shadow:0 5px 15px rgba(0,0,0,.15);

}

</style>

</head>

<body>

<nav>

<div class="logo">

Project Portal

</div>

<ul>

<li><a href="dashboard.php">Dashboard</a></li>

<li><a href="upload.php">Upload</a></li>

<li><a href="my_projects.php">My Projects</a></li>

<li><a href="../logout.php">Logout</a></li>

</ul>

</nav>

<div class="container">

<div class="dashboard-header">

<h2>

Welcome,
<?php echo $_SESSION['student_name']; ?>

👋

</h2>

<p>

Manage your academic projects easily.

</p>

</div>

<div class="row mt-4">

<div class="col-md-3">

<div class="stat-card">

<i class="fa-solid fa-folder-open"></i>

<h3><?php echo $total; ?></h3>

<p>Total Projects</p>

</div>

</div>

<div class="col-md-3">

<div class="stat-card">

<i class="fa-solid fa-hourglass-half"></i>

<h3><?php echo $pending; ?></h3>

<p>Pending</p>

</div>

</div>
<div class="col-md-3">

<div class="stat-card">

<i class="fa-solid fa-circle-check"></i>

<h3><?php echo $approved; ?></h3>

<p>Approved</p>

</div>

</div>

<div class="col-md-3">

<div class="stat-card">

<i class="fa-solid fa-circle-xmark"></i>

<h3><?php echo $rejected; ?></h3>

<p>Rejected</p>

</div>

</div>

</div>

<div class="status-box">

<h3>Latest Project Status</h3>

<hr>

<?php

if($status=="Approved")
{
    echo "<div class='alert alert-success'>
            <h4>✅ Approved</h4>
            Your project has been approved by faculty.
          </div>";
}
elseif($status=="Rejected")
{
    echo "<div class='alert alert-danger'>
            <h4>❌ Rejected</h4>
            Your project needs some improvements.
          </div>";
}
elseif($status=="Pending")
{
    echo "<div class='alert alert-warning'>
            <h4>⏳ Pending</h4>
            Your project is waiting for faculty review.
          </div>";
}
else
{
    echo "<div class='alert alert-secondary'>
            No project uploaded yet.
          </div>";
}

?>

<div class="row mt-4">

<div class="col-md-4">

<a href="upload.php" class="btn btn-primary w-100 p-3">

<i class="fa-solid fa-cloud-arrow-up"></i>

Upload Project

</a>

</div>

<div class="col-md-4">

<a href="my_projects.php" class="btn btn-success w-100 p-3">

<i class="fa-solid fa-folder"></i>

My Projects

</a>

</div>

<div class="col-md-4">

<a href="../logout.php" class="btn btn-danger w-100 p-3">

<i class="fa-solid fa-right-from-bracket"></i>

Logout

</a>

</div>

</div>

</div>

<br><br>

</div>

<footer style="background:#0f172a;color:white;padding:20px;text-align:center;">

<h5>Project Submission Portal</h5>

<p>Developed by <strong>Shashikant</strong></p>

</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>