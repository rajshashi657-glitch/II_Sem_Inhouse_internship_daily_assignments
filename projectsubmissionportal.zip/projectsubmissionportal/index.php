<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Project Submission Portal</title>


<link rel="stylesheet" href="css/style.css">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

</head>

<body>

<nav>

<div class="logo">

<i class="fa-solid fa-graduation-cap"></i>

Project Portal

</div>

<ul>

<li><a href="#">Home</a></li>

<li><a href="#features">Features</a></li>

<li><a href="#about">About</a></li>

<li><a href="login.php">Student Login</a></li>

<li><a href="faculty/login.php">Faculty Login</a></li>

</ul>

</nav>

<section class="hero">

<div class="hero-left">

<h1>

Project Submission Portal

</h1>

<p>

A professional web portal developed for colleges to simplify
project submission, project management and faculty approval.

Students can upload projects online while faculty members
can review, approve or reject submissions from one dashboard.

</p>

<a href="login.php" class="hero-btn">

Student Login

</a>

<a href="faculty/login.php" class="hero-btn">

Faculty Login

</a>

</div>

<div class="hero-image">

<img src="https://undraw.co/api/illustrations/education.svg" alt="">

</div>

</section>

<section id="features">

<h2 class="section-title">

Portal Features

</h2>

<p class="section-subtitle">

Everything required for online project submission.

</p>

<div class="feature-grid">

<div class="feature-box">

<div class="feature-icon">

<i class="fa-solid fa-user-graduate"></i>

</div>

<h3>Student Portal</h3>

<p>

Student Registration, Login,
Upload Projects and Track Status.

</p>

</div>

<div class="feature-box">

<div class="feature-icon">

<i class="fa-solid fa-cloud-arrow-up"></i>

</div>

<h3>Project Upload</h3>

<p>

Upload project files safely with complete details and descriptions.

</p>

</div>

<div class="feature-box">

<div class="feature-icon">

<i class="fa-solid fa-user-check"></i>

</div>

<h3>Faculty Approval</h3>

<p>

Faculty members can approve or reject projects with a single click.

</p>

</div>

</div>

</section>

<section id="about">

<div class="container">

<h2>

About Project

</h2>

<p style="font-size:18px;line-height:32px;">

This portal has been developed using
HTML, CSS, JavaScript, PHP and MySQL.

It helps educational institutes manage project submissions digitally,
reducing paperwork and improving communication between students
and faculty members.

</p>

<br>

<h3>

Developer

</h3>

<p>

<strong>Shashikant</strong><br>

B.Tech Computer Science Engineering<br>

Swami Keshvanand Institute of Technology, Jaipur

</p>

</div>

</section>

<footer>

<h2>

Project Submission Portal

</h2>

<p>

Developed by <b>Shashikant</b>

</p>

<p>

© 2026 All Rights Reserved

</p>

</footer>

</body>
</html>