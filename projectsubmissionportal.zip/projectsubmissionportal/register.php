<?php
include("includes/db.php");

if(isset($_POST['register']))
{
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Check if email already exists
    $check = "SELECT * FROM students WHERE email='$email'";
    $result = mysqli_query($conn, $check);

    if(mysqli_num_rows($result) > 0)
    {
        echo "<script>alert('Email already registered');</script>";
    }
    else
    {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO students(name,email,password)
                VALUES('$name','$email','$hashedPassword')";

        if(mysqli_query($conn,$sql))
        {
            echo "<script>
                    alert('Registration Successful');
                    window.location='login.php';
                  </script>";
        }
        else
        {
            die("Database Error : " . mysqli_error($conn));
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Registration</title>

<link rel="stylesheet" href="css/style.css">

<style>
body{
    background:#eef3f8;
}

.container{
    width:420px;
    margin:60px auto;
    background:white;
    padding:30px;
    border-radius:10px;
    box-shadow:0 0 15px rgba(0,0,0,.15);
}

h2{
    text-align:center;
    margin-bottom:20px;
}

input{
    width:100%;
    padding:12px;
    margin-top:5px;
    margin-bottom:15px;
    border:1px solid #ccc;
    border-radius:6px;
}

input[type=submit]{
    background:#2563eb;
    color:white;
    border:none;
    cursor:pointer;
}

input[type=submit]:hover{
    background:#1d4ed8;
}

p{
    text-align:center;
}
</style>

</head>

<body>

<div class="container">

<h2>Student Registration</h2>

<form method="POST">

<label>Full Name</label>
<input type="text" name="name" required>

<label>Email</label>
<input type="email" name="email" required>

<label>Password</label>
<input type="password" name="password" required>

<input type="submit" name="register" value="Register">

</form>

<p>
Already have an account?
<a href="login.php">Login Here</a>
</p>

</div>s

</body>
</html>