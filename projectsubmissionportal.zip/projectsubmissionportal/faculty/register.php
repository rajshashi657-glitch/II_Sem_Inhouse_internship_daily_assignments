<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include("../includes/db.php");

if(isset($_POST['register']))
{
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $check = "SELECT * FROM faculty WHERE email='$email'";
    $result = mysqli_query($conn, $check);

    if(mysqli_num_rows($result) > 0)
    {
        echo "<script>alert('Faculty Email Already Exists');</script>";
    }
    else
    {
        $sql = "INSERT INTO faculty(name,email,password)
                VALUES('$name','$email','$password')";

        if(mysqli_query($conn, $sql))
        {
            echo "<script>
                    alert('Faculty Registered Successfully');
                    window.location='login.php';
                  </script>";
        }
        else
        {
            die("Database Error : " . mysqli_error($conn));
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Faculty Registration</title>

<link rel="stylesheet" href="../css/style.css">

</head>

<body>

<div class="container">

<h2>Faculty Registration</h2>

<form method="POST">

<label>Name</label><br>
<input type="text" name="name" required><br><br>

<label>Email</label><br>
<input type="email" name="email" required><br><br>

<label>Password</label><br>
<input type="password" name="password" required><br><br>

<input type="submit" name="register" value="Register Faculty">

</form>

</div>

</body>
</html>