<?php
include("includes/db.php");
session_start();

if(isset($_SESSION['student_name']))
{
    header("Location: student/dashboard.php");
    exit();
}

$message = "";

if(isset($_POST['login']))
{
    $email = mysqli_real_escape_string($conn, trim($_POST['email']));
    $password = trim($_POST['password']);

    if(empty($email) || empty($password))
    {
        $message = "<div class='error'>Please fill all fields.</div>";
    }
    else
    {
        $sql = "SELECT * FROM students WHERE email='$email'";
        $result = mysqli_query($conn, $sql);

        if(mysqli_num_rows($result) == 1)
        {
            $row = mysqli_fetch_assoc($result);

            if(password_verify($password, $row['password']))
            {
                $_SESSION['student_name'] = $row['name'];

                header("Location: student/dashboard.php");
                exit();
            }
            else
            {
                $message = "<div class='error'>Incorrect Password!</div>";
            }
        }
        else
        {
            $message = "<div class='error'>Email not registered!</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Student Login</title>

<link rel="stylesheet" href="css/style.css">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">

</head>

<body>

<nav>

<div class="logo">
Project Portal
</div>

<ul>

<li><a href="index.php">Home</a></li>

<li><a href="register.php">Register</a></li>

<li><a href="faculty/login.php">Faculty Login</a></li>

</ul>

</nav>

<div class="container mt-5">

<div class="row justify-content-center">

<div class="col-md-5">

<div class="card shadow-lg border-0 rounded-4">

<div class="card-header bg-primary text-white text-center p-3">

<h3>

<i class="fa-solid fa-user-graduate"></i>

Student Login

</h3>

</div>

<div class="card-body p-4">

<?php
echo $message;
?>

<form method="POST">

<div class="mb-3">

<label class="form-label">

Email Address

</label>

<input
type="email"
name="email"
class="form-control"
placeholder="Enter Email"
required>

</div>

<div class="mb-3">

<label class="form-label">

Password

</label>

<input
type="password"
name="password"
class="form-control"
placeholder="Enter Password"
required>

</div>

<div class="d-grid">

<button
type="submit"
name="login"
class="btn btn-primary btn-lg">

<i class="fa-solid fa-right-to-bracket"></i>

Login

</button>

</div>

</form>

<hr>

<p class="text-center">

Don't have an account?

<a href="register.php">

Register Here

</a>

</p>

</div>

</div>

</div>

</div>

</div>

</body>

</html>