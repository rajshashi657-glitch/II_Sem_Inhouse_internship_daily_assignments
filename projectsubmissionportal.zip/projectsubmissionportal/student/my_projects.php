<?php
include("../includes/db.php");
session_start();

if(!isset($_SESSION['student_name']))
{
    header("Location: ../login.php");
    exit();
}

$student_name=$_SESSION['student_name'];

$result=mysqli_query($conn,"
SELECT * FROM projects
WHERE student_name='$student_name'
ORDER BY id DESC
");
?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width,initial-scale=1">

<title>My Projects</title>

<link rel="stylesheet"
href="../css/style.css">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">

<style>

body{

background:#eef3f8;

}

.table-card{

margin-top:40px;

background:white;

padding:30px;

border-radius:15px;

box-shadow:0 5px 15px rgba(0,0,0,.15);

}

thead{

background:#2563eb;

color:white;

}

.status-pending{

color:#ff9800;

font-weight:bold;

}

.status-approved{

color:green;

font-weight:bold;

}

.status-rejected{

color:red;

font-weight:bold;

}

</style>

</head>

<body>

<nav>

<div class="logo">

Project Portal

</div>

<ul>

<li><a href="dashboard.php">Dashboard</a></li>

<li><a href="upload.php">Upload</a></li>

<li><a href="my_projects.php">My Projects</a></li>

<li><a href="../logout.php">Logout</a></li>

</ul>

</nav>

<div class="container">

<div class="table-card">

<h2 class="text-center mb-4">

<i class="fa-solid fa-folder-open"></i>

My Uploaded Projects

</h2>

<div class="table-responsive">

<table class="table table-bordered table-hover">

<thead>

<tr>

<th>ID</th>

<th>Project</th>

<th>Status</th>

<th>Download</th>

</tr>

</thead>

<tbody>

<?php

if(mysqli_num_rows($result)>0)
{

while($row=mysqli_fetch_assoc($result))
{

?>
<tr>

<td><?php echo $row['id']; ?></td>

<td>

<strong><?php echo $row['project_title']; ?></strong>

<br>

<small>

<?php echo $row['description']; ?>

</small>

</td>

<td>

<?php

if($row['status']=="Approved")
{
    echo "<span class='status-approved'>✅ Approved</span>";
}
elseif($row['status']=="Rejected")
{
    echo "<span class='status-rejected'>❌ Rejected</span>";
}
else
{
    echo "<span class='status-pending'>⏳ Pending</span>";
}

?>

</td>

<td>

<a href="../uploads/<?php echo $row['file_name']; ?>"
class="btn btn-primary btn-sm"
download>

<i class="fa-solid fa-download"></i>

Download

</a>

</td>

</tr>

<?php

}

}
else
{

?>

<tr>

<td colspan="4" class="text-center">

No Projects Uploaded Yet

</td>

</tr>

<?php

}

?>

</tbody>

</table>

</div>

<div class="row mt-4">

<div class="col-md-4">

<a href="upload.php"
class="btn btn-success w-100 p-3">

<i class="fa-solid fa-upload"></i>

Upload New Project

</a>

</div>

<div class="col-md-4">

<a href="dashboard.php"
class="btn btn-secondary w-100 p-3">

<i class="fa-solid fa-house"></i>

Dashboard

</a>

</div>

<div class="col-md-4">

<a href="../logout.php"
class="btn btn-danger w-100 p-3">

<i class="fa-solid fa-right-from-bracket"></i>

Logout

</a>

</div>

</div>

</div>

</div>

<footer style="background:#0f172a;color:white;text-align:center;padding:20px;margin-top:40px;">

<h5>Project Submission Portal</h5>

<p class="mb-0">

Developed by <strong>Shashikant</strong>

</p>

</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>