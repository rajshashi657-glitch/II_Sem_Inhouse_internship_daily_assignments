<?php
include("../includes/db.php");
session_start();

if(!isset($_SESSION['student_name']))
{
    header("Location: ../login.php");
    exit();
}

if(isset($_POST['upload']))
{
    $student_name = $_SESSION['student_name'];
    $project_title = mysqli_real_escape_string($conn, $_POST['project_title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    $file_name = $_FILES['project_file']['name'];
    $temp_name = $_FILES['project_file']['tmp_name'];

    $target = "../uploads/" . basename($file_name);

    if(move_uploaded_file($temp_name, $target))
    {
        $sql = "INSERT INTO projects(student_name, project_title, description, file_name)
                VALUES('$student_name','$project_title','$description','$file_name')";

        if(mysqli_query($conn, $sql))
        {
            echo "<script>
                    alert('Project Uploaded Successfully');
                    window.location='my_projects.php';
                  </script>";
        }
        else
        {
            die("Database Error: " . mysqli_error($conn));
        }
    }
    else
    {
        echo "<script>alert('File Upload Failed');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Upload Project</title>
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>

<div class="container">

<h2>Upload Project</h2>

<form method="POST" enctype="multipart/form-data">

<label>Project Title</label>
<input type="text" name="project_title" required>

<br><br>

<label>Description</label>
<textarea name="description" rows="5" required></textarea>

<br><br>

<label>Select Project File</label>
<input type="file" name="project_file" required>

<br><br>

<input type="submit" name="upload" value="Upload Project">

</form>

<br>

<center>
<a href="dashboard.php">
<button type="button">Back to Dashboard</button>
</a>
</center>

</div>

</body>
</html>