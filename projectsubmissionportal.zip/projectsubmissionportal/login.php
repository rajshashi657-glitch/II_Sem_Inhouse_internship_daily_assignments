<?php
include("includes/db.php");
session_start();

if(isset($_POST['login']))
{
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM students WHERE email='$email'";
    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) > 0)
    {
        $row = mysqli_fetch_assoc($result);

        if(password_verify($password, $row['password']))
        {
            $_SESSION['student_name'] = $row['name'];
            header("Location: student/dashboard.php");
            exit();
        }
        else
        {
            echo "<script>alert('Wrong Password');</script>";
        }
    }
    else
    {
        echo "<script>alert('Email Not Registered');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Login</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="container">

    <h2>Student Login</h2>

    <form method="POST">

        <label>Email</label><br>
        <input type="email" name="email" required><br><br>

        <label>Password</label><br>
        <input type="password" name="password" required><br><br>

        <input type="submit" name="login" value="Login">

    </form>

    <br>

    <p>Don't have an account?
        <a href="register.php">Register Here</a>
    </p>

</div>
<div class="dark-toggle">
    <button onclick="toggleDarkMode()">
        🌙 Dark Mode
    </button>
</div>

<script>

if(localStorage.getItem("theme")=="dark")
{
    document.body.classList.add("dark-mode");
}

function toggleDarkMode()
{
    document.body.classList.toggle("dark-mode");

    if(document.body.classList.contains("dark-mode"))
    {
        localStorage.setItem("theme","dark");
    }
    else
    {
        localStorage.setItem("theme","light");
    }
}

</script>

</body>
</html>

</body>
</html>