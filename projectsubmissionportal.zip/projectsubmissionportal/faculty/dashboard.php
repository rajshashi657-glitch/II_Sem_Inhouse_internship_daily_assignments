<?php
include("../includes/db.php");
session_start();

if(!isset($_SESSION['faculty_name']))
{
    header("Location: login.php");
    exit();
}

if(isset($_GET['approve']))
{
    $id=$_GET['approve'];

    mysqli_query($conn,"UPDATE projects SET status='Approved' WHERE id='$id'");

    header("Location: dashboard.php");

    exit();
}

if(isset($_GET['reject']))
{
    $id=$_GET['reject'];

    mysqli_query($conn,"UPDATE projects SET status='Rejected' WHERE id='$id'");

    header("Location: dashboard.php");

    exit();
}

$total=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM projects"));

$pending=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM projects WHERE status='Pending'"));

$approved=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM projects WHERE status='Approved'"));

$rejected=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM projects WHERE status='Rejected'"));

$result=mysqli_query($conn,"SELECT * FROM projects ORDER BY id DESC");
?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width,initial-scale=1">

<title>Faculty Dashboard</title>

<link rel="stylesheet"
href="../css/style.css">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">

<style>

body{

background:#eef3f8;

}

.header{

background:linear-gradient(135deg,#2563eb,#0f172a);

padding:35px;

color:white;

border-radius:15px;

margin-top:25px;

}

.card-box{

background:white;

padding:20px;

text-align:center;

border-radius:15px;

box-shadow:0 5px 15px rgba(0,0,0,.15);

transition:.3s;

}

.card-box:hover{

transform:translateY(-8px);

}

.card-box i{

font-size:38px;

margin-bottom:10px;

color:#2563eb;

}

.table-card{

margin-top:30px;

background:white;

padding:25px;

border-radius:15px;

box-shadow:0 5px 15px rgba(0,0,0,.15);

}

thead{

background:#2563eb;

color:white;

}

</style>

</head>

<body>

<div class="container">

<div class="header">

<h2>

Welcome,
<?php echo $_SESSION['faculty_name']; ?>

</h2>

<p>

Faculty Project Review Dashboard

</p>

</div>

<div class="row mt-4">

<div class="col-md-3">

<div class="card-box">

<i class="fa-solid fa-folder"></i>

<h3><?php echo $total; ?></h3>

<p>Total Projects</p>

</div>

</div>

<div class="col-md-3">

<div class="card-box">

<i class="fa-solid fa-hourglass-half"></i>

<h3><?php echo $pending; ?></h3>

<p>Pending</p>

</div>

</div>

<div class="col-md-3">

<div class="card-box">

<i class="fa-solid fa-circle-check"></i>

<h3><?php echo $approved; ?></h3>

<p>Approved</p>

</div>

</div>

<div class="col-md-3">

<div class="card-box">

<i class="fa-solid fa-circle-xmark"></i>

<h3><?php echo $rejected; ?></h3>

<p>Rejected</p>

</div>

</div>

</div>

<div class="table-card">

<h3 class="mb-4">

Submitted Projects

</h3>

<div class="table-responsive">

<table class="table table-bordered table-hover">

<thead>

<tr>

<th>ID</th>

<th>Student</th>

<th>Project</th>

<th>Status</th>

<th>Download</th>

<th>Action</th>

</tr>

</thead>

<tbody>

<?php

while($row=mysqli_fetch_assoc($result))
{

?>
<tr>

<td><?php echo $row['id']; ?></td>

<td><?php echo $row['student_name']; ?></td>

<td>

<strong><?php echo $row['project_title']; ?></strong>

<br>

<small><?php echo $row['description']; ?></small>

</td>

<td>

<?php

if($row['status']=="Approved")
{
    echo "<span class='badge bg-success'>Approved</span>";
}
elseif($row['status']=="Rejected")
{
    echo "<span class='badge bg-danger'>Rejected</span>";
}
else
{
    echo "<span class='badge bg-warning text-dark'>Pending</span>";
}

?>

</td>

<td>

<a href="../uploads/<?php echo $row['file_name']; ?>"
class="btn btn-primary btn-sm"
download>

<i class="fa-solid fa-download"></i>

Download

</a>

</td>

<td>

<a href="dashboard.php?approve=<?php echo $row['id']; ?>"
class="btn btn-success btn-sm">

<i class="fa-solid fa-check"></i>

Approve

</a>

<a href="dashboard.php?reject=<?php echo $row['id']; ?>"
class="btn btn-danger btn-sm mt-1">

<i class="fa-solid fa-xmark"></i>

Reject

</a>

</td>

</tr>

<?php

}

?>

</tbody>

</table>

</div>

<div class="row mt-4">

<div class="col-md-6">

<a href="register.php"
class="btn btn-primary w-100 p-3">

<i class="fa-solid fa-user-plus"></i>

Register New Faculty

</a>

</div>

<div class="col-md-6">

<a href="../logout.php"
class="btn btn-dark w-100 p-3">

<i class="fa-solid fa-right-from-bracket"></i>

Logout

</a>

</div>

</div>

</div>

</div>

<footer style="background:#0f172a;color:white;padding:20px;text-align:center;margin-top:40px;">

<h5>Project Submission Portal</h5>

<p class="mb-0">

Developed by <strong>Shashikant</strong>

</p>

</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>